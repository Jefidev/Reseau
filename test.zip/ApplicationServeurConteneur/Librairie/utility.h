#ifndef UTILITY_H_INCLUDED
#define UTILITY_H_INCLUDED

class Utility
{
		
	public :
		static string intToString(int i);
};

#endif